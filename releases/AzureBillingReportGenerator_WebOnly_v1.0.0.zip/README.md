﻿# Azure Billing Report Generator - Web Version

## Quick Start
1. Open zure_billing_generator.html in any modern web browser
2. Upload your Azure billing Excel file or use the sample data
3. Generate professional hierarchical reports

## Sample Data
- example/AzureBilling_Sample_Structure.xlsx - Example file structure
- Click "Download Sample" in the application for the same file

## Features
- No installation required
- Works offline in any browser
- Hierarchical resource grouping
- Markup calculations with customer-safe output
- Professional report generation

## License
Apache 2.0 - see LICENSE file

## More Information
GitHub: https://github.com/cafasdon/azurebillreport
