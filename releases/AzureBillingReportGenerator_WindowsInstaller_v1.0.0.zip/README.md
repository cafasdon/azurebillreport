﻿# Azure Billing Report Generator - Windows Installer Package

## Installation Options

### Option 1: Simple Installation (Recommended)
1. Run INSTALL.bat as Administrator
2. Follow the installation prompts
3. Click the desktop shortcut to launch

### Option 2: Advanced Installation (NSIS)
1. Install NSIS from https://nsis.sourceforge.io/Download
2. Run uild_installer.bat to create professional installer
3. Distribute the generated .exe file

### Option 3: PowerShell Direct
1. Run PowerShell as Administrator
2. Execute: PowerShell -ExecutionPolicy Bypass -File create_simple_installer.ps1

## What Gets Installed
- Desktop shortcut for easy access
- Start Menu integration with shortcuts to:
  - Main application
  - Sample data
  - Documentation
  - GitHub repository
  - Uninstaller
- Windows Add/Remove Programs entry

## Features
- Professional Windows integration
- Complete uninstallation support
- Sample data included
- Comprehensive documentation

## Requirements
- Windows 7 or later
- PowerShell (included in Windows)
- Modern web browser
- Administrator privileges for installation

## License
Apache 2.0 - see LICENSE file

## Support
GitHub: https://github.com/cafasdon/azurebillreport
Documentation: See INSTALLER_README.md for detailed instructions
